from bounded_investigator.prompts import (
    analyzer_instructions,
    analyzer_prompt,
    format_repair_instructions,
    format_repair_prompt,
    gap_reconciliation_instructions,
    gap_reconciliation_prompt,
    render_result_context,
)
from bounded_investigator.schemas import InvestigationResult, InvestigationStatus


def test_prompts_are_external_and_rendered():
    instructions = analyzer_instructions()
    assert "有界调查 Worker" in instructions
    prompt = analyzer_prompt(
        "J00",
        "int main() { return 0; }",
        "[dependency J99]\nsummary: upstream\n[/dependency]",
    )
    assert '<packet name="J00">' in prompt
    assert "int main()" in prompt
    assert "[dependency J99]" in prompt
    assert "{{packet_name}}" not in prompt


def test_compact_result_context_is_not_json_dump():
    result = InvestigationResult(
        status=InvestigationStatus.COMPLETE,
        summary="done",
    )
    text = render_result_context(result)
    assert text.startswith("status: complete")
    assert '"status"' not in text
    assert "claims:" in text


def test_format_repair_prompt_is_external_and_bounded():
    assert "Format Repairer" in format_repair_instructions()
    prompt = format_repair_prompt(
        target_stage="analyzer",
        attempt=1,
        target_schema='{"type":"object"}',
        validation_error="missing field",
        original_raw_output='{"x":1}',
        current_candidate='{"x":1}',
    )
    assert '<repair target_stage="analyzer" attempt="1">' in prompt
    assert "missing field" in prompt
    assert "{{target_schema}}" not in prompt


def test_global_reconciliation_prompt_renders():
    from bounded_investigator.prompts import global_reconciliation_prompt
    rendered = global_reconciliation_prompt("[packet J00]\nclaims: none\n[/packet]")
    assert "reduced_validated_facts" in rendered
    assert "packet J00" in rendered


def test_gap_reconciliation_prompt_renders():
    assert "Global Gap Reconciler" in gap_reconciliation_instructions()
    rendered = gap_reconciliation_prompt("<historical_gaps>R:G001</historical_gaps>")
    assert "R:G001" in rendered
    assert "{{gap_context}}" not in rendered
