# Bounded Investigator v1.7.3 | 证据引用完整性与真实源码报告

本包基于此前 v1.7 完整源码进行发布校验，不是用户提到但未提供的 `261015.zip`。

**验证实际加载版本：**

```powershell
uv sync --reinstall-package bounded-investigator
uv run bounded-investigator version
uv run python -c "from bounded_investigator.schemas import SCHEMA_VERSION; import bounded_investigator.cli as c; print(SCHEMA_VERSION, c.__file__)"
```

预期 `bounded-investigator version` 显示 **1.7.3**，schema 仍显示 **10.0**；本版没有修改 Claim/EvidenceRef Schema。若仍显示 9.3，说明 Python 仍加载的是另一份旧包，请检查输出中的 `loaded_module` 路径；不要仅依据 zip 文件名判断安装成功。


## v1.7.3：Evidence Reference Integrity + 真实源码片段

在 v1.7.2 的旁路证据引用校验基础上，最终确定性报告新增真实源码片段展示。该能力不修改 `BehaviorClaim` / `EvidenceRef` Schema。

本版不增加 EvidenceStore，也不修改 `BehaviorClaim` / `EvidenceRef` 数据契约。LLM 仍输出原来的：

```json
{"location":"F-0500 L47-L69","observation":"..."}
```

程序新增旁路校验：

- Worker Analyzer 输出后校验当前包中的函数和行号，并写入 `_artifacts/Jxx/evidence_validation/analyzer.json`。
- 依赖包引用在单包阶段标记为 `not_in_current_packet`，不会误判为错误；最终使用全部 `J*.md` 再统一核验。
- Reviser 完成后写入 `_artifacts/Jxx/evidence_validation/final.json`，Claim 本身不会增加 validation 字段。
- 最终报告阶段对 Canonical Claim/Artifact 的全部源码引用进行全材料核验，并输出 `_evidence_reference_audit.json`；结果同时进入 `_knowledge_audit.json.evidence_reference_audit`。
- 最终报告对 `confirmed` 和 `suspected` 行为从已验证的 `location` 自动提取真实源码片段；每个行为最多 3 段，全报告默认最多 24 段。
- 源码片段只来自 `J*.md` 原始材料，并保持原始代码内容；无法完整验证引用范围时不展示，不由 LLM 生成代码。
- `lead` 与附录线索继续只保留证据位置，不在正文附加源码，避免报告过度膨胀。
- 已确认行为若没有任何有效源码证据，或存在无效函数/行号引用，报告完整性审计失败；程序不会偷偷修改或降级 Claim。
- 全局整合继续沿用既有 provenance gate：Canonical evidence 必须来自源 Claim/Artifact，不能由 resolver 新造位置。

这项改动只验证“模型引用的位置是否真实存在且可提取”，不自动判断 `observation` 的语义是否正确。

**直接用已保存的结果重生报告（0 LLM 调用）：**

```powershell
uv run bounded-investigator report results/_global_reconciliation.json --config config.yaml --packets-dir testdata/packets --output-dir reported_results
```

这个命令会从真实材料包按函数 ID 和源码行号提取关键代码片段；仅引用实际能找到的行，找不到则不展示，不让 LLM 伪造代码。关键原始证据依然保留在结构化 JSON 中。

**完整重跑：**

```powershell
uv run bounded-investigator batch testdata/packets --manifest testdata/manifest.json --config config.yaml --output-dir results_new
```

**注意：** 用户最新 `results_v17(1).zip` 有 **J14 ModelAPIError: Server disconnected**，因此其中的报告存在调查交付警告。该文件缺失是远端 API 请求失败，不表示项目不含该函数或行为。若要补齐应重新执行 J14 或重跑整个批次，单纯重生报告不会创造缺失事实。

---

# Bounded Investigator v1.7 | 认知保留与确定性报告

基于 v1.6 开发。**本版完成第 7、8、9 步：认知等级归一化、确定性报告生成、逐条来源去向校验。** 原有材料索引、Worker、DAG handoff、Format Repair、Decision-only Global Reconciliation 均保留。

## 完整流程

1. **输入索引**：对实际提交的代码片段、函数范围、额外文件建索引；不预设样本缺少某种材料。
2. **DAG 调度**：根据 `manifest.json` 调度有界调查；验证过的上游摘要传给下游。
3. **有界调查 Agent**：输出 `claims / artifacts / gaps / handoffs / material_needs`。每条 Claim 新增独立的 `evidence_level`：`confirmed / suspected / lead`；`confidence` 是模型信心，**不是**证据完整度。
4. **结果保全**：结构化校验、格式修复、部分记录抢救和原始输出存档。
5. **全局关系消解**：LLM 只给出 Claim merge / supersede / unresolved 关系，程序组装 Canonical Claims/Artifacts 并校验来源。
6. **认知归一化（新增）**：已确认 Claim → 主体；疑似 Claim → 疑似章节；显式 lead、历史 Gap、冲突、旧版未分级 Claim → 调查附录。被覆盖的旧 Claim 只保留审计去向。
7. **确定性报告（新增）**：程序投影行为、IOC、检测特征、调查线索与补料建议；**不调用 Final Evidence Assessment Agent，不预测一份“未知行为清单”**。
8. **认知完整性检查（新增）**：逐个核对 Claim/Artifact 来源与历史 Gap 去向；不匹配时报告标记 `incomplete_provenance` 并单独记入 `_knowledge_audit.json`，不会假装全部完整。

注意：第 2～4 步按 DAG 的实际依赖交替运行，不是一次性的线性批处理。v1.7 仍然需要已有 `J*.md` 和 manifest，不声称能自动拆分任意 PE。

## 三种认知等级

| 类型 | 判断依据 | 报告位置 |
|---|---|---|
| 已确认 `confirmed` | 代码或已验证上下文足以确认**该行为能力**，不要求运行时成功 | **一、核心已确认行为** |
| 疑似 `suspected` | 有具体证据，但关键条件/调用/数据去向未闭合 | **二、疑似行为**，明确写“疑似” |
| 线索 `lead` | 有价值但不足以形成稳定行为结论 | **附录 A：待调查与历史线索** |

另外，`unclassified` 是**旧 JSON 的兼容默认值**，不是模型应该主动选用的第四类。在读取 v1.6 及之前的结果时，由于原来没有该字段，不能仅凭 `confidence=high` 自动升格为确认；这些 Claim 会被保守存入附录，保留原始证据和来源。**若需新报告按三级正常分布，应使用新版本 Worker 重新生成含 `evidence_level` 的调查结果。** Reporter 永不自动重分析和“补标签”。

不要求所有行为都完全闭环才保留，也不会因为某条行为后来被确认就直接删除旧的源记录。被 supersede 的结论保留在来源审计中，最终正文不重复展示旧错误。

## IOC 与检测对象

程序使用现有 `role + detection_specificity` 双维度分组，既保留原子制品，也不把普通系统路径和被读取的数据源当成感染 IOC：

- `iocs`：固定输出、互斥体、配置特征等高价值可检对象；高特异网络端点也可进入。
- `detection_features`：单独不足以确认为感染、但能与进程/行为组合的检测特征。
- `context_artifacts`：普通路径、环境探针目标、被读取数据源、低特异材料，**仍保留在 JSON 和报告附录**。

不单独为每个行为重复“静态代码不能保证运行时成功”之类常识性限制；真正影响行为判断的特有缺口仍可在 Claim `limitations` 中保留。所有原始限制均在报告 JSON 中保存。

## 运行

```bash
uv sync --extra dev
# 把 .env.example 复制为 .env 并填写模型服务的 API Key
```

完整 DAG 分析并自动生成三级报告：

```bash
uv run bounded-investigator batch testdata/packets \
  --manifest testdata/manifest.json \
  --config config.yaml \
  --output-dir results
```

只从 **现有** Global Reconciliation 结果生成报告（0 次 LLM 调用，不需要 API Key），建议先用于比较旧版：

```bash
uv run bounded-investigator report results/_global_reconciliation.json \
  --config config.yaml \
  --output-dir reported_results
```

`assess` 继续作为 `report` 的兼容别名，执行时也**不再**调用最终证据评估模型。会尽可能加载同目录的 `_evidence_scope.json` 和 Jxx 交付状态；需要重建索引时使用可选的 `--packets-dir` 和 `--evidence-dir`。不要求样本专属 `my_scope`。

只重放全局决策整合 + 新报告（不重跑 16 个 Worker，但 Global Reconciliation 仍调用一次配置的 LLM）：

```bash
uv run bounded-investigator reconcile results \
  --config config.yaml \
  --packets-dir testdata/packets \
  --output-dir replayed_results
```

## 交付文件

```text
results/
  J00.json ... J15.json          # 逐包分析、证据、补料及格式修复历史
  _evidence_inventory.json       # 实际提交材料索引
  _material_requests.json       # 分析阶段提出的材料需求
  _evidence_scope.json          # 材料核对及提交状态
  _global_reconciliation.json   # 已验证 canonical facts / historical gaps
  _report_ready.json            # report_ready_v2：完整三级分区 + 全部 canonical 数据
  _final_report.md              # 核心确认 / 疑似 / IOC / 附录线索
  _knowledge_audit.json         # 来源去向 + evidence reference audit
  _evidence_reference_audit.json # 函数/行号源码引用的旁路完整性审计
  _dag_summary.json             # 调度/预算/最终报告状态
```

`_report_ready.json` 的接口已从 v1.6 的 `remaining_uncertainties` 模式升级为 v1.7 的 `core_behaviors / suspected_behaviors / investigation_leads / iocs / detection_features / context_artifacts`。旧消费者需要按新接口读取，不能继续寻找模型生成的 `remaining_uncertainties`。旧的最终评估模块代码保留用于读取历史数据/兼容测试，但**不再进入自动流程**。即使旧配置仍有 `final_evidence_assessment.enabled: true`，v1.7 自动流程也不会调用它。

## 可信边界

- 已确认 = 静态材料支持代码行为能力；不等于对应调用在某台主机实际成功。
- 程序只校验来源、去向和结构，不声称能从源 ID 自动验证模型对汇编/反编译代码的所有解释都正确。
- 以前的历史 Gap 可能已由后续节点回答；报告将其作为**历史调查线索**归档，**不是当前肯定未决的未知项**。
- Raw-only / 交付失败没有可信结构化事实，保留审计警告，不冒充确证或源码缺失。
- 这套机制保障有效结构化认知的**显式去向**，不保证开放式恶意代码分析已经发现所有潜在行为。

## 测试

```bash
uv run pytest -q
python -m compileall -q src
```

离线回归覆盖：Worker/Canonical 认知等级透传、保守合并、旧结果兼容、三段投影、IOC 分流、历史待查保留、supersede 审计、来源计数/重复分配检查、无 Key 无模型的 CLI `report`、原有 DAG/修复/材料索引能力。模型实际分析质量及 `evidence_level` 标注效果，需要在你的模型服务端通过 16 包回归测试复核。
