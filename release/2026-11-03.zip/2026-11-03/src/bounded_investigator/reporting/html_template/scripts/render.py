#!/usr/bin/env python3
"""把报告数据（report.json）渲染成单文件静态 HTML。

用法:
    python render.py report.json -o report.html [--no-toc] [--layout auto|horizontal|vertical] [--legacy]

- 只依赖 Python 标准库；输出不含 JavaScript，也不请求任何外部资源。
- 1.1：首屏增加“关键发现”（按 assets/tier_rules.json 分为恶意 / 可疑 / 信息三档）、证据审计徽章、
  样本信息行；指标条改为可行动的计数；IOC 增加角色与特异性；证据列折叠。
- 渲染前自动校验；有错误时不输出文件并以退出码 1 结束。
- 原始数据以 <script type="application/json" id="report-data"> 嵌入 HTML，便于程序提取。
"""
import argparse
import html
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if __package__:
    from .validate import validate, load_rules, resolve_finding
else:
    from validate import validate, load_rules, resolve_finding

TEMPLATE_VERSION = "1.1"
CSS_PATH = HERE.parent / "assets" / "report.css"

RISK = {
    "critical": ("严重", "CRITICAL", "#B42318"),
    "high": ("高危", "HIGH", "#C2410C"),
    "medium": ("中危", "MEDIUM", "#A16207"),
    "low": ("低危", "LOW", "#1D4ED8"),
    "info": ("信息", "INFO", "#475569"),
}
CALLOUT_LABEL = {"risk": "风险判断", "boundary": "认定边界", "warning": "注意", "info": "说明"}
CALLOUT_TAG = {"risk": "t-risk", "boundary": "t-neutral", "warning": "t-empty", "info": "t-ext"}
HORIZONTAL_MAX = 8
TIER_META = {  # 档位 -> (中文名, css 后缀)
    "malicious": ("恶意", "mal"),
    "suspicious": ("可疑", "sus"),
    "info": ("信息", "info"),
}
SPEC_META = {  # IOC 特异性 -> (显示名, 标签样式)，对应第三阶段的 IOC / 检测特征 / 上下文对象
    "high": ("IOC", "t-ext"),
    "medium": ("检测特征", "t-neutral"),
    "context": ("上下文", "t-muted"),
}
SAMPLE_ORDER = ("filetype", "filename", "size", "arch", "compile_time", "packer")
AUDIT_META = {
    "passed": ("证据审计通过", "audit-pass"),
    "incomplete": ("证据审计未通过", "audit-fail"),
    "not_run": ("证据未审计", "audit-none"),
}
EVIDENCE_SHOW = 3  # 证据列默认展示条数，其余折叠

_CODE = re.compile(r"`([^`]+)`")


def esc(s):
    return html.escape("" if s is None else str(s), quote=True)


def rich(s):
    """转义文本，并把 `xxx` 渲染成行内代码。"""
    return _CODE.sub(lambda m: f"<code>{m.group(1)}</code>", esc(s))


def pad(n):
    return f"{n:02d}"


def slug(s, used):
    base = re.sub(r"[^a-z0-9]+", "-", str(s).lower()).strip("-") or "sec"
    out, i = base, 2
    while out in used:
        out, i = f"{base}-{i}", i + 1
    used.add(out)
    return out


# ---------------------------------------------------------------- 积木
def render_table(columns, rows, mono=(), note=None, dim=(), raw=()):
    """raw：这些列的值是已转义好的 HTML，原样输出。"""
    head = "".join(f"<th>{esc(c)}</th>" for c in columns)
    body = []
    for row in rows:
        cells = []
        for i, v in enumerate(row):
            cls = " class=\"m\"" if i in mono else (" class=\"dim\"" if i in dim else "")
            cells.append(f"<td{cls}>{v if i in raw else rich(v)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    out = f'<div class="tbox"><table><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'
    if note:
        out += f'<p class="note">{rich(note)}</p>'
    return out


def render_block(b):
    t = b["type"]
    if t == "paragraph":
        return f"<p>{rich(b['text'])}</p>"
    if t == "subheading":
        return f"<h3>{rich(b['text'])}</h3>"
    if t == "callout":
        tone = b.get("tone", "info")
        label = b.get("label") or CALLOUT_LABEL[tone]
        return (f'<div class="callout callout-{tone}"><span class="tag {CALLOUT_TAG[tone]}">{esc(label)}</span>'
                f"<div>{rich(b['text'])}</div></div>")
    if t == "table":
        return render_table(b["columns"], b["rows"], set(b.get("mono_columns") or []), b.get("note"))
    if t == "kv":
        cls = ' class="m"' if b.get("mono") else ""
        items = "".join(f"<dt>{rich(i['k'])}</dt><dd{cls}>{rich(i['v'])}</dd>" for i in b["items"])
        return f'<dl class="kv">{items}</dl>'
    if t == "cards":
        cards = []
        for c in b["items"]:
            meta = f'<div class="card-meta">{rich(c["meta"])}</div>' if c.get("meta") else ""
            cards.append(f'<div class="card"><div class="card-title">{rich(c["title"])}</div>{meta}'
                         f'<div class="card-text">{rich(c["text"])}</div></div>')
        return f'<div class="cards">{"".join(cards)}</div>'
    if t == "list":
        return '<ul class="list">' + "".join(f"<li>{rich(i)}</li>" for i in b["items"]) + "</ul>"
    if t == "steps":
        return render_steps(b["items"])
    if t == "code":
        return f'<pre class="code-block"><code>{esc(b["text"])}</code></pre>'
    if t == "tags":
        lbl = f'<span class="lbl">{esc(b["label"])}</span>' if b.get("label") else ""
        return f'<div class="tags">{lbl}' + "".join(f'<span class="tag t-neutral">{esc(i)}</span>' for i in b["items"]) + "</div>"
    if t == "empty":
        return empty(b["label"], b["text"])
    raise ValueError(f"unknown block {t}")


def render_steps(items):
    lis = "".join(f'<li><span class="n">{i}</span><div><b>{rich(s["title"])}</b><span>{rich(s["text"])}</span></div></li>'
                  for i, s in enumerate(items, 1))
    return f'<ol class="steps">{lis}</ol>'


def empty(label, text, ok=False):
    return f'<div class="empty"><span class="tag {"t-ok" if ok else "t-empty"}">{esc(label)}</span><span>{rich(text)}</span></div>'


def section(sid, num, title, body, extra="", question=None):
    q = f'<p class="q">{rich(question)}</p>' if question else ""
    return (f'<section id="{esc(sid)}" class="sec {extra}"><div class="sh"><span class="sn">{esc(num)}</span>'
            f"<h2>{esc(title)}</h2></div>{q}{body}</section>")


def render_evidence(refs, show=EVIDENCE_SHOW):
    """证据列：去重后展示前几条，其余折叠进 <details>。"""
    refs = list(dict.fromkeys(refs or []))
    if not refs:
        return "—"
    head = " · ".join(esc(r) for r in refs[:show])
    if len(refs) <= show:
        return head
    rest = " · ".join(esc(r) for r in refs[show:])
    return f'{head}<details class="ev-more"><summary>另 {len(refs) - show} 条</summary>{rest}</details>'


# ---------------------------------------------------------------- 关键发现
def render_findings(findings, rules, categories, secnum):
    """按档位分组渲染首屏“关键发现”。档位与类别来自规则表。"""
    groups = {t: [] for t in TIER_META}
    for f in findings:
        tier, cat = resolve_finding(f, rules)
        groups.setdefault(tier, []).append((f, categories.get(cat, cat or "未分类")))
    for t in groups:  # 同档内已证实在前，保持输入顺序
        groups[t].sort(key=lambda x: x[0].get("state") != "confirmed")

    def row(f, cat):
        if f.get("state") == "partial":
            st = '<span class="st st-part">部分证实</span>'
            if f.get("state_note"):
                st += f'<span class="fnote">{rich(f["state_note"])}</span>'
        else:
            st = '<span class="st st-ok">已证实</span>'
        ev = list(dict.fromkeys(f.get("evidence") or []))
        meta = [f"{len(ev)} 条证据" if ev else "无证据引用"]
        sid = f.get("section")
        if sid and sid in secnum:
            meta.append(f'<a href="#{esc(sid)}">§{esc(secnum[sid])}</a>')
        rule = "" if f.get("rule") == "CUSTOM" else f' title="规则 {esc(f.get("rule"))}"'
        return (f'<div class="fd"><span class="fcat"{rule}>{esc(cat)}</span>'
                f'<div class="fmain"><span class="ft">{rich(f["title"])}</span>{st}</div>'
                f'<div class="fmeta">{" · ".join(meta)}</div></div>')

    counts = "".join(f'<span class="c-{TIER_META[t][1]}"><b>{len(groups[t])}</b>{TIER_META[t][0]}</span>' for t in TIER_META)
    head = (f'<div class="fhead"><div><div class="eyebrow">KEY FINDINGS</div><h2 id="findings-h">关键发现</h2>'
            f'<p>按规则表分档：恶意＝良性软件几乎不会做；可疑＝需结合上下文；信息＝背景操作。</p></div>'
            f'<div class="fcount">{counts}</div></div>')
    body = []
    for t in ("malicious", "suspicious"):
        label, css = TIER_META[t]
        rows = "".join(row(f, c) for f, c in groups[t]) or f'<div class="fd fd-none">无{label}档发现</div>'
        body.append(f'<div class="tier tier-{css}"><div class="tier-h">{label}<b>{len(groups[t])}</b></div>{rows}</div>')
    if groups["info"]:
        body.append('<details class="tier tier-info"><summary class="tier-h">信息'
                    f'<b>{len(groups["info"])}</b><span class="tier-tip">展开</span></summary>'
                    + "".join(row(f, c) for f, c in groups["info"]) + "</details>")
    return f'<section class="findings" aria-labelledby="findings-h">{head}{"".join(body)}</section>'


# ---------------------------------------------------------------- 行为链总览
def brief(s):
    return f'<span class="stop-brief">{rich(s["brief"])}</span>' if s.get("brief") else ""


def render_flow(chain, layout):
    n = len(chain)
    keys = sum(1 for s in chain if s.get("key"))
    evid = {e for s in chain for e in s.get("evidence", [])}
    legend = '<div class="legend"><span class="dot"></span>核心危害环节</div>' if keys else ""
    head = (f'<div class="flow-head"><div><div class="eyebrow">ATTACK FLOW · {n} STAGES</div>'
            f'<h2 id="flow-h">核心行为链</h2><p>展示有依据的关键行为关系，具体机制见下文章节。</p></div>{legend}</div>')

    if n == 0:
        body = empty("未建立行为链", "当前材料未建立可串联的行为路径；单项行为见下文章节。")
        body = f'<div style="padding-bottom:28px">{body}</div>'
    elif layout == "horizontal" or (layout == "auto" and n <= HORIZONTAL_MAX):
        cols = f"grid-template-columns:repeat({n},minmax(0,1fr))"
        phases = ""
        if any(s.get("phase") for s in chain):
            groups = []
            for i, s in enumerate(chain, 1):
                name = s.get("phase") or "未分组"
                if groups and groups[-1][0] == name:
                    groups[-1][2] = i
                else:
                    groups.append([name, i, i])
            phases = "".join(
                f'<div class="phase" style="grid-column:span {b - a + 1}"><b>{esc(name)}</b>'
                f'<span>{pad(a) if a == b else pad(a) + " – " + pad(b)}</span></div>'
                for name, a, b in groups)
        inset = f"{50 / n:.2f}%"
        line = f'<div class="track-line" style="left:{inset};right:{inset}"></div>' if n > 1 else ""
        stops = "".join(
            f'<div class="stop"><span class="node{" key" if s.get("key") else ""}">{pad(i)}</span>'
            f'<span class="stop-name">{esc(s["name"])}</span>{brief(s)}</div>'
            for i, s in enumerate(chain, 1))
        # 步数少时限制总宽，避免两三个节点被拉得过散
        cap = f";max-width:{n * 240}px" if n <= 4 else ""
        body = (f'<div class="flow-scroll"><div class="flow-grid" style="{cols};min-width:{max(n * 120, 320)}px{cap}">'
                f'{phases}<div class="track" style="{cols}">{line}{stops}</div></div></div>')
    else:
        rows = []
        prev = None
        for i, s in enumerate(chain, 1):
            ph = s.get("phase")
            head_ph = f'<span class="ph">阶段 · {esc(ph)}</span>' if ph and ph != prev else ""
            prev = ph
            rail = "<i></i>" if i < n else ""
            rows.append(f'<div class="vstep"><div class="vrail"><span class="node{" key" if s.get("key") else ""}">{pad(i)}</span>{rail}</div>'
                        f'<div class="vbody">{head_ph}<span class="stop-name">{esc(s["name"])}</span>{brief(s)}</div></div>')
        body = f'<div class="vflow">{"".join(rows)}</div>'

    stats = [f"<span><b>{n}</b>个执行阶段</span>"]
    if keys:
        stats.append(f'<span><b class="red">{keys}</b>个核心危害环节</span>')
    if evid:
        stats.append(f"<span><b>{len(evid)}</b>条证据引用</span>")
    return (f'<section class="flow" aria-labelledby="flow-h">{head}{body}'
            f'<div class="flow-stats">{"".join(stats)}</div></section>')


# ---------------------------------------------------------------- IOC
def render_ioc(items):
    """IOC 表：带角色和特异性时按 IOC → 检测特征 → 上下文排序，并给出分类计数。"""
    if not any(i.get("specificity") or i.get("role") for i in items):  # 1.0 旧数据
        return render_table(["类型", "值", "说明"], [[i["type"], i["value"], i.get("note", "")] for i in items],
                            mono=(1,), dim=(2,))
    order = {k: n for n, k in enumerate(SPEC_META)}
    rows_ = sorted(items, key=lambda i: order.get(i.get("specificity"), len(order)))
    by_type, by_spec = {}, {}
    for i in items:
        by_type[i["type"]] = by_type.get(i["type"], 0) + 1
        sp = SPEC_META.get(i.get("specificity"), ("未标注",))[0]
        by_spec[sp] = by_spec.get(sp, 0) + 1
    summary = ('<div class="ioc-sum"><span>按类型</span>' + " · ".join(f"{esc(k)} <b>{v}</b>" for k, v in by_type.items())
               + '<span>按特异性</span>' + " · ".join(f"{esc(k)} <b>{v}</b>" for k, v in by_spec.items()) + "</div>")

    def spec(i):
        name, css = SPEC_META.get(i.get("specificity"), ("未标注", "t-muted"))
        return f'<span class="tag {css}">{name}</span>'
    table = render_table(["类型", "值", "角色", "特异性", "说明"],
                         [[i["type"], i["value"], i.get("role") or "—", spec(i), i.get("note") or ""] for i in rows_],
                         mono=(1,), dim=(4,), raw=(3,))
    return summary + f'<div class="ioc-t">{table}</div>'


# ---------------------------------------------------------------- 整页
def render(d, layout="auto", toc_on=True):
    m = d["meta"]
    rules, categories = load_rules()
    findings = d.get("findings")  # None = 1.0 旧数据
    tiered = [(f, *resolve_finding(f, rules)) for f in findings or []]
    risk_l, risk_en, risk_c = RISK[m["risk"]]
    chain = d.get("chain") or []
    ioc = d["ioc"]
    host, net = ioc.get("host") or [], ioc.get("network") or []
    attack = d.get("attack") or []
    gaps = d.get("gaps") or []
    attrib = d.get("attribution")
    keys = sum(1 for s in chain if s.get("key"))

    # ---- 报告头 ----
    hashes = "".join(f"<dt>{esc(h['type'])}</dt><dd>{esc(h['value'])}</dd>" for h in d["hashes"]) or "<dt>样本哈希</dt><dd>未提供样本哈希</dd>"
    family = f"{attrib['family']}（{attrib['confidence']}）" if attrib else "未归因"
    facts = [("家族归因", family), ("分析方式", m.get("method") or "未说明"),
             ("报告状态", m.get("status", "—")), ("样本标识", m["id"])]
    facts_html = "".join(f"<div><dt>{esc(k)}</dt><dd>{esc(v)}</dd></div>" for k, v in facts)

    sample = m.get("sample") or {}
    parts_s = [sample[k] for k in SAMPLE_ORDER if sample.get(k)] + [v for k, v in sample.items() if k not in SAMPLE_ORDER and v]
    if sample.get("compile_time"):
        parts_s[parts_s.index(sample["compile_time"])] = "编译 " + sample["compile_time"]
    sample_html = f'<div class="sample-line">{" · ".join(esc(x) for x in parts_s)}</div>' if parts_s else ""

    audit = m.get("audit") or {"status": "not_run"}
    a_label, a_css = AUDIT_META.get(audit.get("status"), AUDIT_META["not_run"])
    tot, bad = audit.get("refs_total"), audit.get("refs_invalid")
    if audit.get("status") == "incomplete" and tot is not None and bad is not None:
        a_label += f" · 失效 {bad}/{tot}"
    elif audit.get("status") == "passed" and tot is not None:
        a_label += f" · {tot} 条引用"
    a_title = f' title="{esc(audit["note"])}"' if audit.get("note") else ""
    audit_html = f'<span class="audit {a_css}"{a_title}>{esc(a_label)}</span>'

    # 能力标签：由关键发现的类别自动生成，恶意档在前
    tags, seen_c = [], set()
    for want in ("malicious", "suspicious"):
        for f, tier, cat in tiered:
            if tier == want and cat not in seen_c:
                seen_c.add(cat)
                tags.append(f'<span class="htag{" mal" if want == "malicious" else ""}">{esc(categories.get(cat, cat))}</span>')
    tags_html = f'<div class="hero-tags">{"".join(tags)}</div>' if tags else ""

    hero = (f'<header class="hero"><div class="wrap">'
            f'<div class="hero-top"><span>{esc(m.get("product", "样本恶意代码分析报告"))}'
            f'{" · " + esc(m["edition"]) if m.get("edition") else ""}</span><span>报告日期 {esc(m["date"])}</span></div>'
            f'<div class="hero-head">{sample_html}<div class="hero-title"><h1>{esc(m["title"])}</h1>'
            f'<span class="risk-badge" style="background:{risk_c}">{risk_l} · {risk_en}</span>{audit_html}</div>{tags_html}</div>'
            f'<p class="verdict">{rich(m["verdict"])}</p>'
            f'<div class="hero-grid"><dl class="hashes">{hashes}</dl><dl class="facts">{facts_html}</dl></div>'
            f"</div></header>")

    # ---- 指标条 ----
    cov = (d.get("scope") or {}).get("coverage") or []
    blocking = sum(1 for g in gaps if g.get("blocking"))
    def spec_note(items, empty_text):
        if not items:
            return empty_text
        if not any(i.get("specificity") for i in items):
            return "未标注特异性"
        return f"其中 IOC {sum(1 for i in items if i.get('specificity') == 'high')} 条"

    if findings is not None:
        kpis = []
        for t, color in (("malicious", "#B42318"), ("suspicious", "#B54708")):
            items = [f for f, tier, _ in tiered if tier == t]
            ok = sum(1 for f in items if f.get("state") == "confirmed")
            kpis.append((f"{TIER_META[t][0]}行为", str(len(items)), f"{ok} 条已证实" if items else "无", color if items else None))
    else:  # 1.0 旧数据没有关键发现，保留原指标
        kpis = [("风险等级", risk_l, risk_en, risk_c),
                ("行为阶段", str(len(chain)), f"{keys} 个核心危害环节" if keys else "—", None)]
    if cov:
        kpis.append((cov[0]["label"], cov[0]["value"], cov[0].get("note") or "", None))
    kpis += [("主机 IOC", str(len(host)), spec_note(host, "未发现"), None),
             ("网络 IOC", str(len(net)), spec_note(net, "未发现"), None),
             ("未决缺口", str(len(gaps)), (f"{blocking} 项阻塞报告" if blocking else "均不阻塞报告") if gaps else "无",
              "#8A4B08" if gaps else None)]
    kpi_html = "".join(
        f'<div class="kpi"><span class="l">{esc(l)}</span><span class="v"{f" style=color:{c}" if c else ""}>{esc(v)}</span>'
        f'<span class="s">{esc(s)}</span></div>' for l, v, s, c in kpis)

    # ---- 章节 ----
    secs = []  # (id, title, body, extra, question, appendix)
    used = {"flow-h"}

    def add(sid, title, body, extra="", question=None, appendix=False):
        used.add(sid)
        secs.append((sid, title, body, extra, question, appendix))

    add("summary", "执行摘要",
        "".join(f"<p>{rich(p)}</p>" for p in d["summary"]) + render_block(
            {"type": "callout", "tone": "risk", "text": d["risk_judgement"]}))

    if d.get("verdict"):
        add("verdict", "结论与影响", render_table(
            ["维度", "结论", "置信度"],
            [[v["dimension"], v["conclusion"], v.get("confidence", "—")] for v in d["verdict"]], dim=(2,)))

    scope = d.get("scope")
    if scope:
        tiles = [f'<div class="tile"><span class="l">{esc(c["label"])}</span><span class="v m">{esc(c["value"])}</span>'
                 f'<span class="s">{esc(c.get("note", ""))}</span></div>' for c in scope.get("coverage") or []]
        if scope.get("inputs"):
            tiles.append(f'<div class="tile"><span class="l">分析输入</span><span class="v">{rich(scope["inputs"])}</span></div>')
        if scope.get("not_covered"):
            tiles.append(f'<div class="tile"><span class="l">未覆盖</span><span class="v">{rich(scope["not_covered"])}</span></div>')
        if tiles:
            add("scope", "分析范围", f'<div class="tiles">{"".join(tiles)}</div>')

    if chain:
        add("chain", "行为链详解", render_table(
            ["阶段", "行为", "证据"],
            [[f"{pad(i)} {s['name']}", s["action"], render_evidence(s.get("evidence"))]
             for i, s in enumerate(chain, 1)], mono=(2,), raw=(2,)))

    for s in d.get("sections") or []:
        sid = s.get("id") or slug(s["title"], used)
        add(sid, s["title"], "".join(render_block(b) for b in s["blocks"]), question=s.get("question"))

    ioc_body = "<h3>文件哈希</h3>" + render_table(
        ["类型", "值", "来源"], [[h["type"], h["value"], h.get("source", "—")] for h in d["hashes"]], mono=(1,), dim=(2,)) if d["hashes"] else empty("样本哈希", "未提供样本哈希。")
    ioc_body += "<h3>主机 IOC</h3>" + (render_ioc(host) if host else empty("无主机 IOC", ioc.get("host_empty_reason", "")))
    ioc_body += "<h3>网络 IOC</h3>" + (render_ioc(net) if net else empty("无网络 IOC", ioc.get("network_empty_reason", "")))
    add("ioc", "IOC", ioc_body)

    if attack:
        add("attack", "MITRE ATT&CK 映射", render_table(
            ["ID", "技术", "本样本证据", "置信度"],
            [[a["id"], a["name"], a["evidence"], a.get("confidence", "—")] for a in attack], mono=(0,), dim=(2, 3)))

    add("detection", "检测建议", "".join(render_block(b) for b in d["detection"]))
    add("response", "应急处置建议", render_steps(d["response"]))

    if attrib:
        nc = attrib.get("not_confirmed") or []
        no = ("" if not nc else
              '<div class="no"><span class="tag t-empty" style="align-self:flex-start">归因 ≠ 静态事实</span>'
              "<p>家族公开描述的以下能力，不能由本样本当前输入直接确认：</p>"
              '<div class="tags" style="margin:0">' + "".join(f'<span class="tag t-neutral">{esc(x)}</span>' for x in nc) + "</div></div>")
        body = ('<div class="attrib"><div class="yes"><span class="tag t-ext" style="align-self:flex-start">外部情报支持</span>'
                f'<span class="fam">{esc(attrib["family"])} · {esc(attrib["confidence"])}</span>'
                + "".join(f"<p>{rich(x)}</p>" for x in attrib["support"]) + f"</div>{no}</div>")
        refs = attrib.get("refs") or []
        if refs:
            body += "<h3>外部参考</h3><ol class=\"refs\">" + "".join(
                f'<li><span class="n">{i}</span><div><b>{esc(r["title"])}</b>'
                f'<a href="{esc(r["url"])}" rel="noopener noreferrer">{esc(r["url"])}</a></div></li>'
                for i, r in enumerate(refs, 1)) + "</ol>"
    else:
        body = empty("未归因", d.get("attribution_empty_reason", ""))
    add("attribution", "家族归因", body)

    add("gaps", "未决缺口与边界", render_table(
        ["缺口", "影响", "阻塞报告"], [[g["gap"], g["impact"], "是" if g["blocking"] else "否"] for g in gaps], dim=(2,))
        if gaps else empty("无未决缺口", "当前报告未列出影响主要结论的未决问题。", ok=True))

    if d.get("functions"):
        add("functions", "关键函数证据索引", render_table(
            ["函数", "地址", "作用", "关键行"],
            [[f["function"], f.get("address", "—"), f["role"], f.get("lines", "—")] for f in d["functions"]], mono=(0, 1, 3)))

    if d.get("yara"):
        add("yara", "YARA 规则", f'<pre class="code-block"><code>{esc(d["yara"])}</code></pre>'
            '<p class="note">规则用于高特异性静态筛查，不替代哈希、行为和内存检测；部署前应在样本集与良性软件集上测试误报率。</p>',
            appendix=True)

    chips = ('<div class="chips">' + "".join(
        f'<span{" class=key" if s.get("key") else ""}>{pad(i)} {esc(s["name"])}</span>' for i, s in enumerate(chain, 1))
        + "</div>") if chain else ""
    add("final", "最终判断", chips + f"<p style=\"margin:0\">{rich(d['final'])}</p>", extra="final", appendix=True)

    # 编号：正文 01.. ，附录 A..
    toc, parts, bi, ai, secnum = [], [], 0, 0, {}
    for sid, title, body, extra, question, appendix in secs:
        if appendix:
            num = "ABCDEFGHIJ"[ai]
            ai += 1
        else:
            bi += 1
            num = pad(bi)
        secnum[sid] = num
        toc.append(f'<a href="#{esc(sid)}"><span>{num}</span>{esc(title)}</a>')
        parts.append(section(sid, num, title, body, extra, question))

    findings_html = render_findings(findings, rules, categories, secnum) if findings is not None else ""
    toc_html = f'<nav class="toc" aria-label="报告目录"><div class="t">目录</div>{"".join(toc)}</nav>' if toc_on else ""
    footer = (f'<footer><span>行为结论与关键对象可通过函数及行号复核。</span>'
              f'<span class="mono">{esc(m.get("tlp", "TLP:AMBER"))} · 模板 v{TEMPLATE_VERSION}</span></footer>')

    data_json = json.dumps(d, ensure_ascii=False, indent=1).replace("</", "<\\/")
    css = CSS_PATH.read_text(encoding="utf-8")
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="generator" content="malware-report-html {TEMPLATE_VERSION}">
<title>{esc(m["title"])}</title>
<style>
{css}
</style>
</head>
<body>
{hero}
<div class="wrap page">
<div class="kpis">{kpi_html}</div>
{findings_html}
{render_flow(chain, layout)}
<div class="layout">
{toc_html}
<main>
{"".join(parts)}
{footer}
</main>
</div>
</div>
<script type="application/json" id="report-data">
{data_json}
</script>
</body>
</html>
"""


def main():
    ap = argparse.ArgumentParser(description="渲染恶意样本分析报告 HTML")
    ap.add_argument("input", help="report.json")
    ap.add_argument("-o", "--output", help="输出 HTML 路径（默认与输入同名 .html）")
    ap.add_argument("--layout", choices=("auto", "horizontal", "vertical"), default="auto",
                    help="行为链布局：auto 时 ≤8 步横向、>8 步纵向")
    ap.add_argument("--no-toc", action="store_true", help="不显示目录侧栏")
    ap.add_argument("--legacy", action="store_true", help="重渲染旧报告：1.1 新增的一致性错误降级为警告")
    args = ap.parse_args()

    src = Path(args.input)
    try:
        data = json.loads(src.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR JSON 解析失败: {e}")
        sys.exit(1)
    errors, warnings = validate(data, legacy=args.legacy)
    for w in warnings:
        print(f"WARN  {w}")
    if errors:
        for e in errors:
            print(f"ERROR {e}")
        print(f"\n校验未通过（{len(errors)} 个错误），未生成 HTML。")
        sys.exit(1)

    out = Path(args.output) if args.output else src.with_suffix(".html")
    out.write_text(render(data, args.layout, not args.no_toc), encoding="utf-8")
    print(f"OK 已生成 {out}（{len(warnings)} 个警告）")


if __name__ == "__main__":
    main()
