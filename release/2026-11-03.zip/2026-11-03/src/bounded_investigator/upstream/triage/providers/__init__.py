"""Concrete triage providers."""
