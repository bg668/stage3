"""Investigation implementation modules."""
