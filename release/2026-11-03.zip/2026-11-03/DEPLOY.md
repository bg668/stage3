# 部署说明（2026-11-03）

要求 Python 3.11 或以上，推荐使用 uv。此包包含当前工作区源码（含尚未提交的更新）、应用 wheel、源码分发包及 uv.lock；不含第三方依赖的离线安装包。首次安装依赖需要网络或已有依赖缓存。

## 安装

解压后在目录中执行：

```powershell
uv sync --locked
Copy-Item .env.example .env
```

编辑 .env 填入密钥，编辑 config.yaml 设置服务地址和模型。随包 config.yaml 复用当前本机模型服务配置，已补齐 planner 阶段、所有服务最小间隔1秒；部署到其他机器时需确保该机器能访问配置的服务地址。未携带真实密钥。

没有 uv 时，也可以创建虚拟环境后安装 dist 下的 wheel；依赖仍需下载：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install .\dist\bounded_investigator-1.7.3-py3-none-any.whl
```

## 检查

```powershell
.\.venv\Scripts\python.exe -m bounded_investigator --help
.\.venv\Scripts\python.exe -m bounded_investigator explore --help
.\.venv\Scripts\python.exe scripts/verify_global.py --help
```

## 从阶段1/2保存结果执行阶段3

样本材料需自行提供。preprocess.json 同级保留 code/ 目录和完整函数原文，triage.json 与其原始哈希引用必须一致。本包不包含 reference、真实样本、历史结果或标准答案。

```powershell
.\.venv\Scripts\python.exe -m bounded_investigator explore `
  --preprocess input/preprocess/preprocess.json `
  --triage input/triage/triage.json `
  --config config.yaml --env-file .env `
  --output-dir results/sample-run --total-tokens 200000
```

结果目录必须是新目录。预算可能使分析部分完成，应检查 exploration_scope.json 和 experiment_manifest.json；CLI退出不代表全样本成功。

## HTML报告

全局整合成功后执行：

```powershell
.\.venv\Scripts\python.exe -m bounded_investigator report-html `
  results/sample-run/results/_global_reconciliation.json `
  --output-dir results/sample-html --config config.yaml --env-file .env `
  --packets-dir results/sample-run/input `
  --packet-results-dir results/sample-run/results
```

HTML编排另有模型调用和独立用量。仅整合已有事实，不重跑函数分析。查看 _html_report_manifest.json，成功后生成 _final_report.html。可用 --context-file 提供真实元信息和实际分析范围，具体格式见 docs/html-report.md。单独验证整合使用 scripts/verify_global.py，见 docs/verify-global.md。

## 已知限制

HTML模型响应可能有字段层级错误；最近一次实际交付曾通过本地移动字段层级修复，不能据此宣称无人干预一次通过。源码和相应诊断流程保留现状，此部署包没有额外改变业务逻辑。

examples/ 已在当前工作区缺失，相关 HTML 示例生成测试会失败；包内正式 HTML 模板、角色及技能资源仍完整。测试文件保留供审查，不能将该缺失测试报成通过。真实模型服务连通性及业务准确率需在部署环境验证。
